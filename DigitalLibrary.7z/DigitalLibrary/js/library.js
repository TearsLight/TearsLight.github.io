// 图书数据
const books = [
    {
        id: 1,
        title: "JavaScript高级程序设计",
        author: "Nicholas C. Zakas",
        category: "tech",
        icon: "💻",
        content: [
            "JavaScript高级程序设计是一本深入讲解JavaScript语言核心概念和高级特性的经典教程。本书从基础语法开始，逐步深入到面向对象编程、DOM操作、事件处理、Ajax通信等高级主题。",
            "第一章：JavaScript简介\n\nJavaScript是一种专为与网页交互而设计的脚本语言，由以下三个不同的部分组成：ECMAScript（核心）、DOM（文档对象模型）、BOM（浏览器对象模型）。",
            "第二章：在HTML中使用JavaScript\n\n要在HTML页面中包含JavaScript，可以使用<script>元素。使用<script>元素的方式有两种：直接在页面中嵌入JavaScript代码和包含外部JavaScript文件。",
            "第三章：基本概念\n\nJavaScript的语法借鉴了C语言和其他类C语言的语法。同时，它也是一门动态语言，变量是松散类型的，可以用来保存任何类型的数据。"
        ]
    },
    {
        id: 2,
        title: "三体",
        author: "刘慈欣",
        category: "fiction",
        icon: "🌌",
        content: [
            "《三体》是刘慈欣创作的长篇科幻小说，是\"地球往事\"系列的第一部。这部作品讲述了地球人类文明和三体文明的信息交流、生死搏杀及两个文明在宇宙中的兴衰历程。",
            "第一章：科学边界\n\n汪淼走进会议室的时候，感到会场的气氛十分凝重。来开会的人并不多，除了他这个纳米材料学家外，还有理论物理学家、天体物理学家、生物学家等。",
            "第二章：三体问题\n\n三体问题是天体力学中的基本力学模型。当三个质量、初始位置和初始速度都是任意的可视为质点的天体，在相互之间万有引力的作用下的运动规律问题。",
            "第三章：红岸基地\n\n红岸基地坐落在大兴安岭深处，是一个绝密的军事研究基地。这里进行着人类历史上最重要的实验之一——向宇宙发送信号。"
        ]
    },
    {
        id: 3,
        title: "人类简史",
        author: "尤瓦尔·赫拉利",
        category: "history",
        icon: "🏛️",
        content: [
            "《人类简史》是以色列新锐历史学家尤瓦尔·赫拉利的代表作。从十万年前有生命迹象开始到21世纪资本、科技交织的人类发展史。",
            "第一章：人类的三大革命\n\n大约135亿年前，宇宙大爆炸之后，出现了物质、能量、时间和空间。这些宇宙基本特征的故事，称之为物理学。",
            "第二章：认知革命\n\n大约7万年前，智人开始创造出更复杂的结构，称为文化。这些文化继续发展，形成了历史学。大约1.2万年前，人类开始驯化动植物。这是农业革命。",
            "第三章：农业革命\n\n农业革命是人类历史上最大的骗局。它让更多的人以更糟的状况活下去。采集者的生活其实比农民要来得轻松有趣，也比较不容易碰到饥荒和疾病。"
        ]
    },
    {
        id: 4,
        title: "算法导论",
        author: "Thomas H. Cormen",
        category: "tech",
        icon: "🧮",
        content: [
            "《算法导论》被称为计算机科学领域最权威的算法教科书。本书深入浅出地介绍了各种算法，包括排序、搜索、图论、动态规划等。",
            "第一章：算法的作用\n\n算法就像是计算机程序的核心，是解决问题的方法和步骤。一个好的算法能够高效地解决问题，而且具有通用性。",
            "第二章：算法分析\n\n算法分析是对算法性能的研究，主要关注时间复杂度和空间复杂度。时间复杂度描述算法运行时间随输入规模增长的趋势。",
            "第三章：排序算法\n\n排序是计算机科学中最基本的问题之一。本章介绍了插入排序、归并排序、快速排序等经典算法。"
        ]
    },
    {
        id: 5,
        title: "设计心理学",
        author: "唐纳德·诺曼",
        category: "art",
        icon: "🎨",
        content: [
            "《设计心理学》是设计学的经典之作，探讨了设计如何影响人的行为和心理。好的设计应该是直观的、易用的。",
            "第一章：日用品的设计\n\n好的设计应该是不言自明的。当你看到一个物品时，应该立即知道如何使用它，而不需要说明书或者思考。",
            "第二章：可见性原则\n\n可见性是好设计的关键要素。用户应该能够看到可能的操作选项，以及操作的结果。隐藏的功能往往会让用户困惑。",
            "第三章：反馈和映射\n\n好的设计提供及时的反馈。当用户执行操作时，系统应该立即响应，让用户知道操作是否成功。"
        ]
    },
    {
        id: 6,
        title: "经济学原理",
        author: "格里高利·曼昆",
        category: "business",
        icon: "💼",
        content: [
            "《经济学原理》是经济学入门的经典教材，以清晰易懂的方式介绍了微观经济学和宏观经济学的基本概念。",
            "第一章：经济学十大原理\n\n经济学研究社会如何管理自己的稀缺资源。这里介绍经济学的十大原理，它们是经济学思维的基础。",
            "第二章：供求关系\n\n市场经济中，价格由供求关系决定。当需求增加或供给减少时，价格上升；反之则价格下降。",
            "第三章：市场效率\n\n在理想的竞争市场中，资源配置是有效的。市场机制通过价格信号引导资源流向最有价值的用途。"
        ]
    }
];


let currentBooks = [...books];
let currentPage = 0;
let currentBook = null;
let isDarkTheme = false;
let isReaderDark = false;
let isPageMode = false; // false: 下滑翻页, true: 左右翻页

// 初始化
document.addEventListener('DOMContentLoaded', function() {
    displayBooks(currentBooks);
    
    // 搜索框回车事件
    document.getElementById('searchInput').addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            searchBooks();
        }
    });

    // 阅读器滚动翻页
    document.getElementById('pageContent').addEventListener('scroll', function(e) {
        if (!isPageMode && currentBook) {
            const element = e.target;
            const scrollPercentage = element.scrollTop / (element.scrollHeight - element.clientHeight) * 100;
            const pageIndex = Math.floor(scrollPercentage / (100 / currentBook.content.length));
            if (pageIndex !== currentPage && pageIndex < currentBook.content.length) {
                currentPage = pageIndex;
                updatePageIndicator();
            }
        }
    });
});

// 显示图书
function displayBooks(booksToShow) {
    const bookGrid = document.getElementById('bookGrid');
    bookGrid.innerHTML = '';

    booksToShow.forEach(book => {
        const bookCard = document.createElement('div');
        bookCard.className = 'book-card';
        bookCard.innerHTML = `
            <div class="book-cover" style="background: linear-gradient(45deg, ${getRandomColor()}, ${getRandomColor()})">${book.icon}</div>
            <div class="book-title">${book.title}</div>
            <div class="book-author">${book.author}</div>
        `;
        bookCard.addEventListener('click', () => openReader(book));
        bookGrid.appendChild(bookCard);
    });
}

// 随机颜色生成
function getRandomColor() {
    const colors = ['#ff9a9e', '#fecfef', '#ffecd2', '#fcb69f', '#a8edea', '#fed6e3', '#d299c2', '#fef9d7'];
    return colors[Math.floor(Math.random() * colors.length)];
}

// 搜索图书
function searchBooks() {
    const query = document.getElementById('searchInput').value.toLowerCase();
    if (query.trim() === '') {
        currentBooks = [...books];
    } else {
        currentBooks = books.filter(book => 
            book.title.toLowerCase().includes(query) || 
            book.author.toLowerCase().includes(query)
        );
    }
    displayBooks(currentBooks);
}

// 分类筛选
function filterBooks(category) {
    if (category === 'all') {
        currentBooks = [...books];
    } else {
        currentBooks = books.filter(book => book.category === category);
    }
    displayBooks(currentBooks);
}

// 切换主题
function toggleTheme() {
    isDarkTheme = !isDarkTheme;
    document.body.classList.toggle('dark-theme', isDarkTheme);
    document.querySelector('.theme-toggle').textContent = isDarkTheme ? '☀️' : '🌙';
}

// 打开阅读器
function openReader(book) {
    currentBook = book;
    currentPage = 0;
    document.getElementById('readerModal').style.display = 'block';
    document.getElementById('readerTitle').textContent = book.title;
    loadPage();
}

// 关闭阅读器
function closeReader() {
    document.getElementById('readerModal').style.display = 'none';
    currentBook = null;
}

// 加载页面内容
function loadPage() {
    if (!currentBook) return;
    
    const pageContent = document.getElementById('pageContent');
    if (isPageMode) {
        // 左右翻页模式
        pageContent.innerHTML = currentBook.content[currentPage] || '暂无内容';
        pageContent.style.overflow = 'hidden';
    } else {
        // 下滑翻页模式
        pageContent.innerHTML = currentBook.content.join('<br><br>');
        pageContent.style.overflow = 'auto';
        // 滚动到对应位置
        const scrollPosition = (currentPage / currentBook.content.length) * pageContent.scrollHeight;
        pageContent.scrollTop = scrollPosition;
    }
    updatePageIndicator();
}

// 上一页
function prevPage() {
    if (currentPage > 0) {
        currentPage--;
        if (isPageMode) {
            loadPage();
        } else {
            const pageContent = document.getElementById('pageContent');
            const scrollPosition = (currentPage / currentBook.content.length) * pageContent.scrollHeight;
            pageContent.scrollTo({ top: scrollPosition, behavior: 'smooth' });
        }
        updatePageIndicator();
    }
}

// 下一页
function nextPage() {
    if (currentPage < currentBook.content.length - 1) {
        currentPage++;
        if (isPageMode) {
            loadPage();
        } else {
            const pageContent = document.getElementById('pageContent');
            const scrollPosition = (currentPage / currentBook.content.length) * pageContent.scrollHeight;
            pageContent.scrollTo({ top: scrollPosition, behavior: 'smooth' });
        }
        updatePageIndicator();
    }
}

// 更新页码指示器
function updatePageIndicator() {
    if (currentBook) {
        document.getElementById('pageIndicator').textContent = 
            `第 ${currentPage + 1} 页 / 共 ${currentBook.content.length} 页`;
    }
}

// 切换阅读器主题
function toggleReaderTheme() {
    isReaderDark = !isReaderDark;
    const readerContent = document.getElementById('readerContent');
    if (isReaderDark) {
        readerContent.style.background = '#2c3e50';
        readerContent.style.color = 'white';
    } else {
        readerContent.style.background = 'white';
        readerContent.style.color = 'black';
    }
}

// 切换翻页模式
function changePageMode() {
    isPageMode = !isPageMode;
    loadPage();
}

// 键盘快捷键
document.addEventListener('keydown', function(e) {
    if (document.getElementById('readerModal').style.display === 'block') {
        if (e.key === 'ArrowLeft') {
            prevPage();
        } else if (e.key === 'ArrowRight') {
            nextPage();
        } else if (e.key === 'Escape') {
            closeReader();
        }
    }
});

function loadTxtBook(title, author, category, icon, path) {
    fetch(path)
        .then(res => res.text())
        .then(text => {
            const paragraphs = text
                .split(/\n\s*\n/) // 空行分段
                .map(p => p.trim())
                .filter(p => p.length > 0);

            const book = {
                id: books.length + 1,
                title: title,
                author: author,
                category: category,
                icon: icon,
                content: paragraphs
            };

            books.push(book);
            currentBooks = [...books];
            displayBooks(currentBooks); // 重新渲染图书列表
        })
        .catch(err => console.error(`加载 ${title} 失败：`, err));
}
